import { Router } from 'express';
import { db } from '../db.js';
import { requireAuth, checkSchoolScope } from '../auth.js';

const router = Router();

// GET dashboard statistics
router.get('/stats', requireAuth, async (req, res) => {
  const schoolId = (req.query.schoolId as string) || req.user!.schoolId;

  if (schoolId && !checkSchoolScope(req, schoolId)) {
    return res.status(403).json({ error: 'Access denied to this school dashboard.' });
  }

  try {
    const isSuperAdminView = !schoolId && (req.user!.roleName === 'super_admin' || req.user!.permissions.includes('schools.switch'));

    // 1. Schools summary
    const schoolsRes = await db.query(`
      SELECT s.*,
        (SELECT count(*) FROM classes c WHERE c.school_id = s.id AND c.status = 'active') as classes_count,
        (SELECT count(*) FROM sections sec WHERE sec.school_id = s.id AND sec.status = 'active') as sections_count,
        (SELECT count(*) FROM users u WHERE u.school_id = s.id AND u.status = 'active') as users_count,
        (SELECT name FROM academic_sessions ses WHERE ses.school_id = s.id AND ses.is_current = true LIMIT 1) as current_session_name
      FROM schools s
      ${schoolId ? 'WHERE s.id = $1' : ''}
      ORDER BY s.name ASC
    `, schoolId ? [schoolId] : []);

    // 2. Count aggregates
    let countFilters = '';
    const countParams: any[] = [];
    if (schoolId) {
      countFilters = 'WHERE school_id = $1';
      countParams.push(schoolId);
    }

    const whereActive = schoolId ? 'WHERE school_id = $1 AND status = \'active\'' : 'WHERE status = \'active\'';
    const classesCountRes = await db.query(`SELECT count(*) as count FROM classes ${whereActive}`, countParams);
    const sectionsCountRes = await db.query(`SELECT count(*) as count FROM sections ${whereActive}`, countParams);
    const usersCountRes = await db.query(`SELECT count(*) as count FROM users ${whereActive}`, countParams);
    const totalCapacityRes = await db.query(`SELECT COALESCE(SUM(capacity), 0) as capacity FROM sections ${whereActive}`, countParams);

    // Phase 2 Student & Parent metrics
    const studentFilter = schoolId ? 'WHERE school_id = $1' : '';
    const totalStudentsRes = await db.query(`SELECT count(*) as count FROM students ${studentFilter}`, schoolId ? [schoolId] : []);
    const activeStudentsRes = await db.query(`SELECT count(*) as count FROM students ${studentFilter ? studentFilter + " AND student_status = 'ACTIVE'" : "WHERE student_status = 'ACTIVE'"}`, schoolId ? [schoolId] : []);
    const totalParentsRes = await db.query(`SELECT count(*) as count FROM parents ${studentFilter}`, schoolId ? [schoolId] : []);

    // Phase 4 Staff metrics
    const staffFilter = schoolId ? 'WHERE school_id = $1' : '';
    const totalStaffRes = await db.query(`SELECT count(*) as count FROM employees ${staffFilter}`, schoolId ? [schoolId] : []);
    const activeStaffRes = await db.query(`SELECT count(*) as count FROM employees ${staffFilter ? staffFilter + " AND employment_status = 'ACTIVE'" : "WHERE employment_status = 'ACTIVE'"}`, schoolId ? [schoolId] : []);
    const teachingStaffRes = await db.query(`SELECT count(*) as count FROM employees ${staffFilter ? staffFilter + " AND employee_type = 'Teaching'" : "WHERE employee_type = 'Teaching'"}`, schoolId ? [schoolId] : []);
    const nonTeachingStaffRes = await db.query(`SELECT count(*) as count FROM employees ${staffFilter ? staffFilter + " AND employee_type = 'Non-Teaching'" : "WHERE employee_type = 'Non-Teaching'"}`, schoolId ? [schoolId] : []);

    // Demographics
    const maleRes = await db.query(`SELECT count(*) as count FROM students ${studentFilter ? studentFilter + " AND gender = 'Male'" : "WHERE gender = 'Male'"}`, schoolId ? [schoolId] : []);
    const femaleRes = await db.query(`SELECT count(*) as count FROM students ${studentFilter ? studentFilter + " AND gender = 'Female'" : "WHERE gender = 'Female'"}`, schoolId ? [schoolId] : []);
    const otherRes = await db.query(`SELECT count(*) as count FROM students ${studentFilter ? studentFilter + " AND gender = 'Other'" : "WHERE gender = 'Other'"}`, schoolId ? [schoolId] : []);

    // Class Enrollment & Active Student Counts
    const classEnrollQuery = `
      SELECT 
        c.name as class_name,
        c.numeric_grade,
        (SELECT count(*) FROM students s WHERE s.class_id = c.id AND s.student_status = 'ACTIVE') as student_count,
        COALESCE((SELECT sum(sec.capacity) FROM sections sec WHERE sec.class_id = c.id AND sec.status = 'active'), 0) as capacity
      FROM classes c
      ${schoolId ? 'WHERE c.school_id = $1 AND c.status = \'active\'' : 'WHERE c.status = \'active\''}
      ORDER BY c.numeric_grade ASC
    `;
    const classEnrollRes = await db.query(classEnrollQuery, schoolId ? [schoolId] : []);

    // Aggregate class enrollment across sections/schools if not single school
    const classEnrollMap = new Map<string, { class_name: string; student_count: number; capacity: number }>();
    for (const row of classEnrollRes.rows as any[]) {
      const name = row.class_name;
      const count = parseInt(row.student_count || '0', 10);
      const cap = parseInt(row.capacity || '0', 10);
      if (classEnrollMap.has(name)) {
        const item = classEnrollMap.get(name)!;
        item.student_count += count;
        item.capacity += cap;
      } else {
        classEnrollMap.set(name, {
          class_name: name,
          student_count: count,
          capacity: cap
        });
      }
    }
    const cleanClassEnrollment = Array.from(classEnrollMap.values());

    // 3. Classes by grade breakdown
    let gradeQuery = `
      SELECT c.stream, count(c.id) as class_count, sum((SELECT count(sec.id) FROM sections sec WHERE sec.class_id = c.id AND sec.status = 'active')) as section_count
      FROM classes c
      ${schoolId ? 'WHERE c.school_id = $1 AND c.status = \'active\'' : 'WHERE c.status = \'active\''}
      GROUP BY c.stream
      ORDER BY class_count DESC
    `;
    const gradeBreakdownRes = await db.query(gradeQuery, schoolId ? [schoolId] : []);

    // 4. Monthly Fee Collection Trends (Academic Session 2025-26: Apr to Mar)
    const feeTrendsQuery = `
      SELECT 
        TO_CHAR(payment_date, 'Mon') as month_name,
        EXTRACT(MONTH FROM payment_date) as month_num,
        EXTRACT(YEAR FROM payment_date) as year_num,
        COALESCE(SUM(amount), 0) as collected_amount,
        count(*) as transaction_count
      FROM fee_payments
      WHERE status = 'SUCCESS' ${schoolId ? 'AND school_id = $1' : ''}
      GROUP BY TO_CHAR(payment_date, 'Mon'), EXTRACT(MONTH FROM payment_date), EXTRACT(YEAR FROM payment_date)
      ORDER BY year_num ASC, month_num ASC
    `;
    const feeTrendsRes = await db.query(feeTrendsQuery, schoolId ? [schoolId] : []);

    // Map into standard Indian academic session (April 2025 to March 2026)
    const academicMonths = [
      { month: 'Apr', monthFull: 'April 2025', target: 35000 },
      { month: 'May', monthFull: 'May 2025', target: 12000 },
      { month: 'Jun', monthFull: 'June 2025', target: 12000 },
      { month: 'Jul', monthFull: 'July 2025', target: 25000 },
      { month: 'Aug', monthFull: 'August 2025', target: 12000 },
      { month: 'Sep', monthFull: 'September 2025', target: 12000 },
      { month: 'Oct', monthFull: 'October 2025', target: 25000 },
      { month: 'Nov', monthFull: 'November 2025', target: 10000 },
      { month: 'Dec', monthFull: 'December 2025', target: 10000 },
      { month: 'Jan', monthFull: 'January 2026', target: 20000 },
      { month: 'Feb', monthFull: 'February 2026', target: 10000 },
      { month: 'Mar', monthFull: 'March 2026', target: 15000 }
    ];

    const monthlyFeeTrends = academicMonths.map((m) => {
      const match = (feeTrendsRes.rows as any[]).find(
        (r) => r.month_name && r.month_name.toLowerCase().startsWith(m.month.toLowerCase())
      );
      const collected = match ? parseFloat(match.collected_amount || '0') : 0;
      const transactions = match ? parseInt(match.transaction_count || '0', 10) : 0;
      const rate = m.target > 0 ? Math.round((collected / m.target) * 100) : 0;
      return {
        month: m.month,
        monthFull: m.monthFull,
        collected,
        target: m.target,
        transactions,
        rate
      };
    });

    // 5. Recent audit activity
    let auditQuery = `
      SELECT a.id, a.user_name, a.user_role, a.action, a.module, a.description, a.created_at, s.code as school_code
      FROM audit_logs a
      LEFT JOIN schools s ON a.school_id = s.id
      ${schoolId ? 'WHERE a.school_id = $1 OR a.school_id IS NULL' : ''}
      ORDER BY a.created_at DESC
      LIMIT 8
    `;
    const recentAuditRes = await db.query(auditQuery, schoolId ? [schoolId] : []);

    return res.json({
      isSuperAdminView,
      stats: {
        totalSchools: schoolsRes.rows.length,
        totalClasses: parseInt((classesCountRes.rows[0] as any).count, 10),
        totalSections: parseInt((sectionsCountRes.rows[0] as any).count, 10),
        totalUsers: parseInt((usersCountRes.rows[0] as any).count, 10),
        totalStudentCapacity: parseInt((totalCapacityRes.rows[0] as any).capacity, 10),
        totalStudents: parseInt((totalStudentsRes.rows[0] as any).count, 10),
        activeStudents: parseInt((activeStudentsRes.rows[0] as any).count, 10),
        totalParents: parseInt((totalParentsRes.rows[0] as any).count, 10),
        totalStaff: parseInt((totalStaffRes.rows[0] as any).count, 10),
        activeStaff: parseInt((activeStaffRes.rows[0] as any).count, 10),
        teachingStaff: parseInt((teachingStaffRes.rows[0] as any).count, 10),
        nonTeachingStaff: parseInt((nonTeachingStaffRes.rows[0] as any).count, 10)
      },
      schools: schoolsRes.rows,
      streamBreakdown: gradeBreakdownRes.rows,
      studentDemographics: {
        totalMale: parseInt((maleRes.rows[0] as any).count, 10),
        totalFemale: parseInt((femaleRes.rows[0] as any).count, 10),
        totalOther: parseInt((otherRes.rows[0] as any).count, 10)
      },
      classEnrollment: cleanClassEnrollment,
      monthlyFeeTrends,
      recentActivity: recentAuditRes.rows
    });
  } catch (err: any) {
    console.error('[DASHBOARD STATS ERROR]', err);
    return res.status(500).json({ error: err.message || 'Failed to retrieve dashboard stats.' });
  }
});

export default router;
