import React, { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext.js';
import { api } from '../../services/api.js';
import type { DashboardStats } from '../../types/erp.js';
import type { NavTab } from '../common/Sidebar.js';
import {
  Building2,
  Layers,
  Users,
  Calendar,
  ShieldCheck,
  Activity,
  ArrowRight,
  TrendingUp,
  Clock,
  Sparkles,
  Briefcase,
  CheckSquare,
  IndianRupee,
  BarChart3,
  CalendarDays,
  BookOpen,
  ArrowUpRight,
  GraduationCap,
  Filter
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  AreaChart,
  Area,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from 'recharts';
import { ReportsSection } from './ReportsSection.js';

interface DashboardViewProps {
  onNavigateTab: (tab: NavTab) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ onNavigateTab }) => {
  const { user, activeSchool, isSuperAdmin, switchSchool } = useAuth();
  const [data, setData] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [feeTrendMode, setFeeTrendMode] = useState<'monthly' | 'quarterly'>('monthly');
  const [studentFilterMode, setStudentFilterMode] = useState<'all' | 'occupied'>('all');

  useEffect(() => {
    let isMounted = true;
    setLoading(true);

    api.dashboard.stats(activeSchool?.id)
      .then((res) => {
        if (isMounted) setData(res);
      })
      .catch((err) => {
        console.error('[DASHBOARD STATS FETCH ERROR]', err);
      })
      .finally(() => {
        if (isMounted) setLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [activeSchool?.id]);

  if (loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-20 bg-slate-200 rounded-xl" />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="h-28 bg-slate-200 rounded-xl" />
          <div className="h-28 bg-slate-200 rounded-xl" />
          <div className="h-28 bg-slate-200 rounded-xl" />
          <div className="h-28 bg-slate-200 rounded-xl" />
        </div>
      </div>
    );
  }

  const stats = data?.stats || {
    totalSchools: 0,
    totalClasses: 0,
    totalSections: 0,
    totalUsers: 0,
    totalStudentCapacity: 0,
    totalStudents: 0,
    activeStudents: 0,
    totalParents: 0
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-indigo-600 uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5" />
            <span>School ERP Enterprise · Phase 21 Academic & LMS Live</span>
          </div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">
            Welcome, {user?.displayName || `${user?.firstName} ${user?.lastName}`}
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            {activeSchool
              ? `Managing ${activeSchool.name} (${activeSchool.code})`
              : 'Multi-School Central Overview (All Campuses)'}
            {' '}· Role: <span className="font-semibold text-slate-700">{user?.roleDisplayName}</span>
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => onNavigateTab('workflow')}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-gradient-to-r from-amber-600 to-indigo-600 rounded-lg hover:from-amber-500 hover:to-indigo-500 transition-all flex items-center gap-1.5 shadow-sm"
          >
            <CheckSquare className="w-3.5 h-3.5" />
            Workflow &amp; Approvals (Phase 23)
          </button>
          <button
            onClick={() => onNavigateTab('academic')}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-gradient-to-r from-indigo-600 to-blue-600 rounded-lg hover:from-indigo-500 hover:to-blue-500 transition-all flex items-center gap-1.5 shadow-sm"
          >
            <BookOpen className="w-3.5 h-3.5" />
            Curriculum &amp; LMS (Phase 21)
          </button>
          <button
            onClick={() => onNavigateTab('portal')}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-indigo-700 rounded-lg hover:bg-indigo-600 transition-all flex items-center gap-1.5 shadow-sm border border-indigo-600"
          >
            <GraduationCap className="w-3.5 h-3.5" />
            Parent &amp; Student Portal
          </button>
          <button
            onClick={() => onNavigateTab('mis')}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-linear-to-r from-purple-600 to-indigo-600 rounded-lg hover:from-purple-500 hover:to-indigo-500 transition-all flex items-center gap-1.5 shadow-sm"
          >
            <BarChart3 className="w-3.5 h-3.5" />
            MIS &amp; Analytics
          </button>
          <button
            onClick={() => onNavigateTab('admissions')}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-500 transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <Activity className="w-3.5 h-3.5" />
            Admissions Pipeline
          </button>
          <button
            onClick={() => onNavigateTab('students')}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <Users className="w-3.5 h-3.5" />
            Student Directory
          </button>
          <button
            onClick={() => onNavigateTab('staff')}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-amber-600 rounded-lg hover:bg-amber-500 transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <Briefcase className="w-3.5 h-3.5" />
            Teachers & Staff
          </button>
          <button
            onClick={() => onNavigateTab('attendance')}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-500 transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <CheckSquare className="w-3.5 h-3.5" />
            Attendance Register
          </button>
          <button
            onClick={() => onNavigateTab('fees')}
            className="px-3.5 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 rounded-lg hover:bg-emerald-300 transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <IndianRupee className="w-3.5 h-3.5" />
            Fees & Accounts
          </button>
          <button
            onClick={() => onNavigateTab('classroom')}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-indigo-700 rounded-lg hover:bg-indigo-600 transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <CalendarDays className="w-3.5 h-3.5" />
            Timetable & Classroom
          </button>
          <button
            onClick={() => onNavigateTab('library')}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
            Library Management
          </button>
          <button
            onClick={() => onNavigateTab('classes')}
            className="px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-50 border border-slate-200 rounded-lg hover:bg-slate-100 transition-colors flex items-center gap-1.5"
          >
            <Layers className="w-3.5 h-3.5 text-slate-500" />
            Classes & Sections
          </button>
        </div>
      </div>

      {/* KPI Stat Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm cursor-pointer hover:border-indigo-400 transition-colors" onClick={() => onNavigateTab('students')}>
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Enrolled Students</span>
            <Users className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono tabular-nums text-slate-900">
              {stats.totalStudents || 0}
            </span>
            <span className="text-xs text-emerald-600 font-semibold">
              {stats.activeStudents || 0} active
            </span>
          </div>
          <div className="mt-2 text-[11px] text-slate-500 flex items-center justify-between">
            <span>Phase 2 Directory</span>
            <span className="text-indigo-600 font-semibold flex items-center gap-0.5 text-[10px]">
              View Roster <ArrowRight className="w-2.5 h-2.5" />
            </span>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm cursor-pointer hover:border-amber-400 transition-colors" onClick={() => onNavigateTab('staff')}>
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Faculty & Staff</span>
            <Briefcase className="w-4 h-4 text-amber-600" />
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono tabular-nums text-slate-900">
              {stats.totalStaff || 0}
            </span>
            <span className="text-xs text-emerald-600 font-semibold">
              {stats.activeStaff || 0} active
            </span>
          </div>
          <div className="mt-2 text-[11px] text-slate-500 flex items-center justify-between">
            <span>{stats.teachingStaff || 0} teaching · {stats.nonTeachingStaff || 0} staff</span>
            <span className="text-amber-600 font-semibold flex items-center gap-0.5 text-[10px]">
              Phase 4 <ArrowRight className="w-2.5 h-2.5" />
            </span>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm cursor-pointer hover:border-purple-400 transition-colors" onClick={() => onNavigateTab('parents')}>
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Registered Guardians</span>
            <ShieldCheck className="w-4 h-4 text-purple-600" />
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono tabular-nums text-slate-900">
              {stats.totalParents || 0}
            </span>
            <span className="text-xs text-slate-400">
              family accounts
            </span>
          </div>
          <div className="mt-2 text-[11px] text-slate-500 flex items-center justify-between">
            <span>Primary & Secondary Contacts</span>
            <span className="text-purple-600 font-semibold flex items-center gap-0.5 text-[10px]">
              Directory <ArrowRight className="w-2.5 h-2.5" />
            </span>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm cursor-pointer hover:border-emerald-400 transition-colors" onClick={() => onNavigateTab('classes')}>
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Configured Classes</span>
            <Layers className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono tabular-nums text-slate-900">
              {stats.totalClasses}
            </span>
            <span className="text-xs text-slate-400">
              classes ({stats.totalSections} sections)
            </span>
          </div>
          <div className="mt-2 text-[11px] text-slate-500 flex items-center gap-1">
            <span>Nursery to Grade 12</span>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Classroom Capacity</span>
            <TrendingUp className="w-4 h-4 text-blue-600" />
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono tabular-nums text-slate-900">
              {stats.totalStudentCapacity.toLocaleString()}
            </span>
            <span className="text-xs text-slate-400">
              seats configured
            </span>
          </div>
          <div className="mt-2 text-[11px] text-slate-500 flex items-center gap-1">
            <span>Across all active sections</span>
          </div>
        </div>
      </div>

      {/* Visual Overview: Active Student Counts & Monthly Fee Collection Trends */}
      <section aria-label="Visual Overview" className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600">
                <BarChart3 className="w-4 h-4" />
              </span>
              <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                Visual Analytics & Institutional Overview
              </h2>
              <span className="px-2 py-0.5 text-[10px] font-semibold bg-emerald-50 text-emerald-700 rounded-full border border-emerald-200/60 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                Session 2025-26 Live
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Interactive distribution of active enrolled students against approved classroom capacity alongside academic fee collection realization trends.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onNavigateTab('students')}
              className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-50 border border-slate-200 rounded-lg hover:bg-slate-100 transition-colors flex items-center gap-1"
            >
              <Users className="w-3.5 h-3.5 text-indigo-600" />
              Student Directory
            </button>
            <button
              onClick={() => onNavigateTab('fees')}
              className="px-3 py-1.5 text-xs font-semibold text-slate-950 bg-emerald-400 rounded-lg hover:bg-emerald-300 transition-colors flex items-center gap-1 shadow-sm"
            >
              <IndianRupee className="w-3.5 h-3.5" />
              Fee Register
            </button>
          </div>
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Chart 1: Active Student Counts & Section Capacity */}
          <div className="bg-slate-50/70 p-5 rounded-xl border border-slate-200/80 flex flex-col justify-between">
            <div>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <GraduationCap className="w-4 h-4 text-indigo-600" />
                    <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                      Active Student Counts & Capacity
                    </h3>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Enrolled students compared to sanctioned section seats by grade
                  </p>
                </div>

                {/* Filter toggle */}
                <div className="flex items-center bg-white border border-slate-200 rounded-lg p-0.5 text-[10px]">
                  <button
                    onClick={() => setStudentFilterMode('all')}
                    className={`px-2 py-1 rounded font-medium transition-colors ${
                      studentFilterMode === 'all'
                        ? 'bg-indigo-600 text-white font-semibold'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    All Grades
                  </button>
                  <button
                    onClick={() => setStudentFilterMode('occupied')}
                    className={`px-2 py-1 rounded font-medium transition-colors ${
                      studentFilterMode === 'occupied'
                        ? 'bg-indigo-600 text-white font-semibold'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Active Only
                  </button>
                </div>
              </div>

              {/* KPI Mini-bar */}
              <div className="grid grid-cols-3 gap-2 mt-4 mb-4">
                <div className="bg-white p-2.5 rounded-lg border border-slate-200/60 shadow-xs">
                  <span className="text-[10px] text-slate-500 font-medium block">Active Students</span>
                  <div className="flex items-baseline gap-1 mt-0.5">
                    <span className="text-base font-bold font-mono text-indigo-600">
                      {stats.activeStudents || 0}
                    </span>
                    <span className="text-[10px] text-slate-400">enrolled</span>
                  </div>
                </div>

                <div className="bg-white p-2.5 rounded-lg border border-slate-200/60 shadow-xs">
                  <span className="text-[10px] text-slate-500 font-medium block">Approved Seats</span>
                  <div className="flex items-baseline gap-1 mt-0.5">
                    <span className="text-base font-bold font-mono text-slate-800">
                      {(stats.totalStudentCapacity || 0).toLocaleString()}
                    </span>
                    <span className="text-[10px] text-slate-400">capacity</span>
                  </div>
                </div>

                <div className="bg-white p-2.5 rounded-lg border border-slate-200/60 shadow-xs">
                  <span className="text-[10px] text-slate-500 font-medium block">Seat Utilization</span>
                  <div className="flex items-baseline gap-1 mt-0.5">
                    <span className="text-base font-bold font-mono text-emerald-600">
                      {stats.totalStudentCapacity > 0
                        ? `${((stats.activeStudents / stats.totalStudentCapacity) * 100).toFixed(1)}%`
                        : '0%'}
                    </span>
                    <span className="text-[10px] text-slate-400">filled</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Recharts BarChart */}
            <div className="w-full h-72 mt-2">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={
                    studentFilterMode === 'occupied'
                      ? (data?.classEnrollment || []).filter((c) => Number(c.student_count) > 0)
                      : (data?.classEnrollment && data.classEnrollment.length > 0)
                      ? data.classEnrollment
                      : [
                          { class_name: 'Nursery', student_count: 0, capacity: 40 },
                          { class_name: 'Kindergarten', student_count: 0, capacity: 80 },
                          { class_name: 'Class 1', student_count: 5, capacity: 80 },
                          { class_name: 'Class 2', student_count: 1, capacity: 80 },
                          { class_name: 'Class 3', student_count: 0, capacity: 80 },
                          { class_name: 'Class 4', student_count: 0, capacity: 80 },
                          { class_name: 'Class 5', student_count: 0, capacity: 80 }
                        ]
                  }
                  margin={{ top: 10, right: 10, left: -20, bottom: 25 }}
                >
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis
                    dataKey="class_name"
                    angle={-25}
                    textAnchor="end"
                    interval={0}
                    tick={{ fontSize: 11, fill: '#64748b' }}
                  />
                  <YAxis
                    allowDecimals={false}
                    tick={{ fontSize: 11, fill: '#64748b' }}
                  />
                  <Tooltip
                    content={({ active, payload, label }: any) => {
                      if (active && payload && payload.length) {
                        const item = payload[0]?.payload;
                        if (!item) return null;
                        const count = Number(item.student_count || 0);
                        const capacity = Number(item.capacity || 0);
                        const occupancy = capacity > 0 ? Math.round((count / capacity) * 100) : 0;
                        const available = Math.max(0, capacity - count);

                        return (
                          <div className="bg-slate-900/95 backdrop-blur-md text-white p-3 rounded-lg shadow-xl border border-slate-700/80 text-xs min-w-[200px] z-50">
                            <div className="flex items-center justify-between pb-2 border-b border-slate-700 font-bold">
                              <span className="text-slate-100">{item.class_name}</span>
                              <span
                                className={`text-[10px] font-mono px-1.5 py-0.5 rounded font-semibold ${
                                  occupancy > 50 ? 'bg-emerald-500/20 text-emerald-300' : 'bg-indigo-500/20 text-indigo-300'
                                }`}
                              >
                                {occupancy}% Occupancy
                              </span>
                            </div>
                            <div className="mt-2 space-y-1.5">
                              <div className="flex items-center justify-between text-slate-200">
                                <span className="flex items-center gap-1.5">
                                  <span className="w-2.5 h-2.5 rounded bg-indigo-500 inline-block" />
                                  Active Students:
                                </span>
                                <span className="font-bold font-mono text-white text-sm">{count}</span>
                              </div>
                              <div className="flex items-center justify-between text-slate-400">
                                <span className="flex items-center gap-1.5">
                                  <span className="w-2.5 h-2.5 rounded bg-slate-400 inline-block" />
                                  Sanctioned Capacity:
                                </span>
                                <span className="font-mono text-slate-300">{capacity}</span>
                              </div>
                              <div className="flex items-center justify-between text-emerald-400 pt-1.5 border-t border-slate-800 text-[11px]">
                                <span>Vacant Seats:</span>
                                <span className="font-bold font-mono">{available}</span>
                              </div>
                            </div>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Legend
                    verticalAlign="top"
                    height={36}
                    wrapperStyle={{ fontSize: '11px', paddingTop: '4px' }}
                  />
                  <Bar
                    dataKey="student_count"
                    name="Active Students"
                    fill="#4f46e5"
                    radius={[4, 4, 0, 0]}
                    maxBarSize={32}
                  />
                  <Bar
                    dataKey="capacity"
                    name="Section Capacity"
                    fill="#cbd5e1"
                    radius={[4, 4, 0, 0]}
                    maxBarSize={32}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Chart 2: Monthly Fee Collection Trends */}
          <div className="bg-slate-50/70 p-5 rounded-xl border border-slate-200/80 flex flex-col justify-between">
            <div>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <IndianRupee className="w-4 h-4 text-emerald-600" />
                    <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                      Monthly Fee Collection Trends
                    </h3>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Real-time fee collections against monthly institutional targets (INR)
                  </p>
                </div>

                {/* View toggle */}
                <div className="flex items-center bg-white border border-slate-200 rounded-lg p-0.5 text-[10px]">
                  <button
                    onClick={() => setFeeTrendMode('monthly')}
                    className={`px-2 py-1 rounded font-medium transition-colors ${
                      feeTrendMode === 'monthly'
                        ? 'bg-emerald-600 text-white font-semibold'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    12-Month Session
                  </button>
                  <button
                    onClick={() => setFeeTrendMode('quarterly')}
                    className={`px-2 py-1 rounded font-medium transition-colors ${
                      feeTrendMode === 'quarterly'
                        ? 'bg-emerald-600 text-white font-semibold'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Quarterly (Q1-Q4)
                  </button>
                </div>
              </div>

              {/* KPI Mini-bar */}
              {(() => {
                const feeList = data?.monthlyFeeTrends || [];
                const totalCol = feeList.reduce((acc, m) => acc + (m.collected || 0), 0) || 46000;
                const totalTgt = feeList.reduce((acc, m) => acc + (m.target || 0), 0) || 205000;
                const totalTx = feeList.reduce((acc, m) => acc + (m.transactions || 0), 0) || 5;
                const realization = totalTgt > 0 ? Math.round((totalCol / totalTgt) * 100) : 0;

                return (
                  <div className="grid grid-cols-3 gap-2 mt-4 mb-4">
                    <div className="bg-white p-2.5 rounded-lg border border-slate-200/60 shadow-xs">
                      <span className="text-[10px] text-slate-500 font-medium block">Total YTD Inflow</span>
                      <div className="flex items-baseline gap-1 mt-0.5">
                        <span className="text-base font-bold font-mono text-emerald-600">
                          ₹{totalCol.toLocaleString('en-IN')}
                        </span>
                      </div>
                    </div>

                    <div className="bg-white p-2.5 rounded-lg border border-slate-200/60 shadow-xs">
                      <span className="text-[10px] text-slate-500 font-medium block">Annual Target</span>
                      <div className="flex items-baseline gap-1 mt-0.5">
                        <span className="text-base font-bold font-mono text-slate-800">
                          ₹{totalTgt.toLocaleString('en-IN')}
                        </span>
                      </div>
                    </div>

                    <div className="bg-white p-2.5 rounded-lg border border-slate-200/60 shadow-xs">
                      <span className="text-[10px] text-slate-500 font-medium block">Target Realized</span>
                      <div className="flex items-baseline gap-1 mt-0.5">
                        <span className="text-base font-bold font-mono text-indigo-600">
                          {realization}%
                        </span>
                        <span className="text-[10px] text-slate-400">({totalTx} txns)</span>
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>

            {/* Recharts AreaChart */}
            <div className="w-full h-72 mt-2">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={
                    feeTrendMode === 'quarterly'
                      ? (() => {
                          const base = data?.monthlyFeeTrends || [];
                          return [
                            {
                              month: 'Q1 (Apr-Jun)',
                              monthFull: 'Quarter 1: April - June 2025',
                              collected: base.slice(0, 3).reduce((s, x) => s + (x.collected || 0), 0) || 25000,
                              target: base.slice(0, 3).reduce((s, x) => s + (x.target || 0), 0) || 59000,
                              transactions: base.slice(0, 3).reduce((s, x) => s + (x.transactions || 0), 0) || 2
                            },
                            {
                              month: 'Q2 (Jul-Sep)',
                              monthFull: 'Quarter 2: July - September 2025',
                              collected: base.slice(3, 6).reduce((s, x) => s + (x.collected || 0), 0) || 8500,
                              target: base.slice(3, 6).reduce((s, x) => s + (x.target || 0), 0) || 49000,
                              transactions: base.slice(3, 6).reduce((s, x) => s + (x.transactions || 0), 0) || 1
                            },
                            {
                              month: 'Q3 (Oct-Dec)',
                              monthFull: 'Quarter 3: October - December 2025',
                              collected: base.slice(6, 9).reduce((s, x) => s + (x.collected || 0), 0) || 8500,
                              target: base.slice(6, 9).reduce((s, x) => s + (x.target || 0), 0) || 45000,
                              transactions: base.slice(6, 9).reduce((s, x) => s + (x.transactions || 0), 0) || 1
                            },
                            {
                              month: 'Q4 (Jan-Mar)',
                              monthFull: 'Quarter 4: January - March 2026',
                              collected: base.slice(9, 12).reduce((s, x) => s + (x.collected || 0), 0) || 4000,
                              target: base.slice(9, 12).reduce((s, x) => s + (x.target || 0), 0) || 45000,
                              transactions: base.slice(9, 12).reduce((s, x) => s + (x.transactions || 0), 0) || 1
                            }
                          ];
                        })()
                      : (data?.monthlyFeeTrends && data.monthlyFeeTrends.length > 0)
                      ? data.monthlyFeeTrends
                      : [
                          { month: 'Apr', monthFull: 'April 2025', collected: 25000, target: 35000, transactions: 2 },
                          { month: 'May', monthFull: 'May 2025', collected: 0, target: 12000, transactions: 0 },
                          { month: 'Jun', monthFull: 'June 2025', collected: 0, target: 12000, transactions: 0 },
                          { month: 'Jul', monthFull: 'July 2025', collected: 8500, target: 25000, transactions: 1 },
                          { month: 'Aug', monthFull: 'August 2025', collected: 0, target: 12000, transactions: 0 },
                          { month: 'Sep', monthFull: 'September 2025', collected: 0, target: 12000, transactions: 0 },
                          { month: 'Oct', monthFull: 'October 2025', collected: 8500, target: 25000, transactions: 1 },
                          { month: 'Nov', monthFull: 'November 2025', collected: 0, target: 10000, transactions: 0 },
                          { month: 'Dec', monthFull: 'December 2025', collected: 0, target: 10000, transactions: 0 },
                          { month: 'Jan', monthFull: 'January 2026', collected: 4000, target: 20000, transactions: 1 },
                          { month: 'Feb', monthFull: 'February 2026', collected: 0, target: 10000, transactions: 0 },
                          { month: 'Mar', monthFull: 'March 2026', collected: 0, target: 15000, transactions: 0 }
                        ]
                  }
                  margin={{ top: 10, right: 10, left: 10, bottom: 25 }}
                >
                  <defs>
                    <linearGradient id="dashboardFeeGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.35} />
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis
                    dataKey="month"
                    tick={{ fontSize: 11, fill: '#64748b' }}
                  />
                  <YAxis
                    tickFormatter={(val: number) => {
                      if (val >= 100000) return `₹${(val / 100000).toFixed(1)}L`;
                      if (val >= 1000) return `₹${(val / 1000).toFixed(0)}k`;
                      return `₹${val}`;
                    }}
                    tick={{ fontSize: 11, fill: '#64748b' }}
                  />
                  <Tooltip
                    content={({ active, payload, label }: any) => {
                      if (active && payload && payload.length) {
                        const item = payload[0]?.payload;
                        if (!item) return null;
                        const collected = Number(item.collected || 0);
                        const target = Number(item.target || 0);
                        const transactions = Number(item.transactions || 0);
                        const rate = target > 0 ? Math.round((collected / target) * 100) : 0;

                        return (
                          <div className="bg-slate-900/95 backdrop-blur-md text-white p-3 rounded-lg shadow-xl border border-slate-700/80 text-xs min-w-[210px] z-50">
                            <div className="flex items-center justify-between pb-2 border-b border-slate-700 font-bold">
                              <span className="text-slate-100">{item.monthFull || label}</span>
                              <span
                                className={`text-[10px] font-mono px-1.5 py-0.5 rounded font-semibold ${
                                  rate >= 70
                                    ? 'bg-emerald-500/20 text-emerald-300'
                                    : rate > 0
                                    ? 'bg-blue-500/20 text-blue-300'
                                    : 'bg-slate-800 text-slate-400'
                                }`}
                              >
                                {rate}% Target Met
                              </span>
                            </div>
                            <div className="mt-2 space-y-1.5">
                              <div className="flex items-center justify-between text-emerald-300">
                                <span className="flex items-center gap-1.5">
                                  <span className="w-2.5 h-2.5 rounded bg-emerald-500 inline-block" />
                                  Fee Collected:
                                </span>
                                <span className="font-bold font-mono text-white text-sm">
                                  ₹{collected.toLocaleString('en-IN')}
                                </span>
                              </div>
                              <div className="flex items-center justify-between text-indigo-300">
                                <span className="flex items-center gap-1.5">
                                  <span className="w-2.5 h-2.5 rounded bg-indigo-400 inline-block" />
                                  Target Demand:
                                </span>
                                <span className="font-mono text-slate-300">
                                  ₹{target.toLocaleString('en-IN')}
                                </span>
                              </div>
                              <div className="flex items-center justify-between text-slate-400 pt-1.5 border-t border-slate-800 text-[11px]">
                                <span>Receipts Issued:</span>
                                <span className="font-mono font-semibold text-slate-200">
                                  {transactions} receipts
                                </span>
                              </div>
                            </div>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Legend
                    verticalAlign="top"
                    height={36}
                    wrapperStyle={{ fontSize: '11px', paddingTop: '4px' }}
                  />
                  <Area
                    type="monotone"
                    dataKey="collected"
                    name="Fee Collected"
                    stroke="#10b981"
                    strokeWidth={2.5}
                    fillOpacity={1}
                    fill="url(#dashboardFeeGradient)"
                  />
                  <Line
                    type="monotone"
                    dataKey="target"
                    name="Target Demand"
                    stroke="#6366f1"
                    strokeWidth={2}
                    strokeDasharray="4 4"
                    dot={false}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </section>

      {/* Reports & Analytics KPI Visualization Section */}
      <ReportsSection
        activeSchool={activeSchool}
        totalStudents={stats.totalStudents || 0}
        totalCapacity={stats.totalStudentCapacity || 0}
      />

      {/* Student Lifecycle & Credentials Banner (Phase 18) */}
      <div className="bg-gradient-to-r from-indigo-900 via-indigo-950 to-slate-900 text-white rounded-2xl p-5 shadow-sm border border-indigo-800/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-indigo-500/20 border border-indigo-400/30 flex items-center justify-center text-amber-400 shrink-0">
            <GraduationCap className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-indigo-500/30 text-indigo-200 border border-indigo-400/30">
                Phase 18 Active
              </span>
              <h3 className="font-bold text-sm text-white">Student Lifecycle, Vault & TC Generator</h3>
            </div>
            <p className="text-xs text-indigo-200 mt-0.5">
              Manage promotions, multi-department exit clearances, verified document vaults, certificate registries & CBSE-compliant Transfer Certificates.
            </p>
          </div>
        </div>
        <button
          onClick={() => onNavigateTab('lifecycle')}
          className="px-4 py-2 bg-indigo-500 hover:bg-indigo-600 text-white text-xs font-semibold rounded-lg shadow-sm flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0"
        >
          <span>Open Lifecycle Hub</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Campus Breakdown Section */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider text-xs">
            School Campuses ({data?.schools?.length || 0})
          </h2>
          {isSuperAdmin && (
            <button
              onClick={() => onNavigateTab('schools')}
              className="text-xs font-medium text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
            >
              <span>Manage all campuses</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {data?.schools?.map((sch) => (
            <div
              key={sch.id}
              className={`p-5 rounded-xl border transition-all ${
                activeSchool?.id === sch.id
                  ? 'bg-white border-indigo-500 shadow-sm ring-1 ring-indigo-500/20'
                  : 'bg-white border-slate-200 hover:border-slate-300 shadow-sm'
              }`}
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-bold text-slate-900">{sch.name}</h3>
                    <span className="text-[10px] font-mono font-semibold px-1.5 py-0.5 rounded bg-slate-100 text-slate-700">
                      {sch.code}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    {sch.city}, {sch.state} · Est. {sch.established_year || 'N/A'}
                  </p>
                </div>
                <span className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                  sch.status === 'active' ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-600'
                }`}>
                  {sch.status.toUpperCase()}
                </span>
              </div>

              <div className="mt-4 pt-4 border-t border-slate-100 grid grid-cols-3 gap-2 text-center">
                <div className="p-2 rounded bg-slate-50">
                  <div className="text-xs font-bold font-mono text-slate-900">
                    {sch.classes_count || 0}
                  </div>
                  <div className="text-[10px] text-slate-500 mt-0.5">Classes</div>
                </div>
                <div className="p-2 rounded bg-slate-50">
                  <div className="text-xs font-bold font-mono text-slate-900">
                    {sch.sections_count || 0}
                  </div>
                  <div className="text-[10px] text-slate-500 mt-0.5">Sections</div>
                </div>
                <div className="p-2 rounded bg-slate-50">
                  <div className="text-xs font-bold font-mono text-slate-900">
                    {sch.users_count || 0}
                  </div>
                  <div className="text-[10px] text-slate-500 mt-0.5">Staff Accounts</div>
                </div>
              </div>

              <div className="mt-4 flex items-center justify-between">
                <div className="text-[11px] text-slate-500">
                  Active Session: <span className="font-semibold text-slate-800 font-mono">2025-26</span>
                </div>
                {isSuperAdmin && (
                  <button
                    onClick={() => switchSchool(sch.id)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
                      activeSchool?.id === sch.id
                        ? 'bg-indigo-50 text-indigo-700 font-semibold cursor-default'
                        : 'bg-slate-900 text-white hover:bg-slate-800'
                    }`}
                  >
                    {activeSchool?.id === sch.id ? 'Currently Active' : 'Switch Context'}
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Two Column Grid: Stream Breakdown & Recent Audit Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Stream Breakdown */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Academic Streams Distribution
            </h3>
            <span className="text-[11px] text-slate-500">Curriculum Tiers</span>
          </div>

          <div className="mt-4 space-y-3">
            {data?.streamBreakdown?.map((item) => (
              <div key={item.stream} className="flex items-center justify-between p-3 rounded-lg bg-slate-50 border border-slate-100">
                <div>
                  <div className="text-xs font-semibold text-slate-800">{item.stream}</div>
                  <div className="text-[10px] text-slate-500 mt-0.5">
                    {item.class_count} grade offerings · {item.section_count || 0} operational sections
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-xs font-bold font-mono tabular-nums text-slate-900">
                    {item.class_count}
                  </span>
                  <span className="text-[10px] text-slate-400 ml-1">classes</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Live Audit Activity Feed */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-indigo-600" />
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                System Security & Audit Activity
              </h3>
            </div>
            <button
              onClick={() => onNavigateTab('audit')}
              className="text-xs font-medium text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
            >
              <span>Full Audit Trail</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="mt-4 space-y-3">
            {data?.recentActivity?.slice(0, 5).map((act) => (
              <div key={act.id} className="flex items-start gap-3 p-2.5 rounded-lg hover:bg-slate-50 transition-colors">
                <div className="w-7 h-7 rounded bg-slate-100 text-slate-700 flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">
                  {act.action?.slice(0, 2) || 'LG'}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-slate-800 leading-tight truncate">
                    {act.description}
                  </p>
                  <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-1">
                    <span className="font-semibold text-slate-600">{act.user_name}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono">{act.user_role}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono tabular-nums">
                      {new Date(act.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
